package String;


public class StringExample{    
public static void main(String args[]){    
String s1="java";//creating string by Java string literal    
char ch[]={'s','t','r','i','n','g','s'};    
String s2=new String(ch);//converting char array to string    
String s3=new String("example");//creating Java string by new keyword    
System.out.println(s1);    
System.out.println(s2);    
System.out.println(s3);    
}}    



//.concat

class Testimmutablestring{  
	 public static void main(String args[]){  
	   String s="Sachin";  
	   s.concat(" Tendulkar");//concat() method appends the string at the end  
	   System.out.println(s);//will print Sachin because strings are immutable objects  
	 }  
	}  


class Testimmutablestring1{  
	 public static void main(String args[]){  
	   String s="Sachin";  
	   s=s.concat(" Tendulkar");  
	   System.out.println(s);  
	 }  
	} 






class Teststringcomparison1{  
	 public static void main(String args[]){  
	   String s1="Sachin";  
	   String s2="Sachin";  
	   String s3=new String("Sachin");  
	   String s4="Saurav";  
	   System.out.println(s1.equals(s2));//true  
	   System.out.println(s1.equals(s3));//true  
	   System.out.println(s1.equals(s4));//false  
	 }  
	}  




class Teststringcomparison2{  
	 public static void main(String args[]){  
	   String s1="Sachin";  
	   String s2="SACHIN";  
	  
	   System.out.println(s1.equals(s2));//false  
	   System.out.println(s1.equalsIgnoreCase(s2));//true  
	 }  
	}  





class Teststringcomparison3{  
	 public static void main(String args[]){  
	   String s1="Sachin";  
	   String s2="Sachin";  
	   String s3=new String("Sachin");  
	   System.out.println(s1==s2);//true (because both refer to same instance)  
	   System.out.println(s1==s3);//false(because s3 refers to instance created in nonpool)  
	 }  
	}  






class TestStringConcatenation1{  
	 public static void main(String args[]){  
	   String s="Sachin"+" Tendulkar";  
	   System.out.println(s);//Sachin Tendulkar  
	 }  
	}  


class TestStringConcatenation3{  
	 public static void main(String args[]){  
	   String s1="Sachin ";  
	   String s2="Tendulkar";  
	   String s3=s1.concat(s2);  
	   System.out.println(s3);//Sachin Tendulkar  
	  }  
	}  




public class StrBuilder  
{  
    /* Driver Code */  
    public static void main(String args[])  
    {  
        StringBuilder s1 = new StringBuilder("Hello");    //String 1  
        StringBuilder s2 = new StringBuilder(" World");    //String 2  
        StringBuilder s = s1.append(s2);   //String 3 to store the result  
            System.out.println(s.toString());  //Displays result  
    }  
} 





public class StrFormat  
{  
    /* Driver Code */  
    public static void main(String args[])  
    {  
        String s1 = new String("Hello");    //String 1  
        String s2 = new String(" World");    //String 2  
        String s = String.format("%s%s",s1,s2);   //String 3 to store the result  
            System.out.println(s.toString());  //Displays result  
    }  
}  








public class TestSubstring{    
	 public static void main(String args[]){    
	 String s="SachinTendulkar";    
	 System.out.println("Original String: " + s);  
	 System.out.println("Substring starting from index 6: " +s.substring(6));//Tendulkar    
	 System.out.println("Substring starting from index 0 to 6: "+s.substring(0,6)); //Sachin  
	 }  
	}    




import java.util.*;  

public class TestSubstring2  
{    
    /* Driver Code */  
    public static void main(String args[])  
    {    
        String text= new String("Hello, My name is Sachin");  
        /* Splits the sentence by the delimeter passed as an argument */  
        String[] sentences = text.split("\\.");  
        System.out.println(Arrays.toString(sentences));  
    }  
} 





public class Stringoperation1  
{  
public static void main(String ar[])  
{  
String s="Sachin";    
System.out.println(s.toUpperCase());//SACHIN    
System.out.println(s.toLowerCase());//sachin    
System.out.println(s);//Sachin(no change in original)    
}  
}  


public class Stringoperation2  
{  
public static void main(String ar[])  
{  
String s="  Sachin  ";    
System.out.println(s);//  Sachin      
System.out.println(s.trim());//Sachin    
}  
}  



public class Stringoperation3  
{  
public static void main(String ar[])  
{  
String s="Sachin";    
 System.out.println(s.startsWith("Sa"));//true    
 System.out.println(s.endsWith("n"));//true    
}  
}  



public class Stringoperation4  
{  
public static void main(String ar[])  
{  
String s="Sachin";    
System.out.println(s.charAt(0));//S    
System.out.println(s.charAt(3));//h    
}  
} 




public class Stringoperation5  
{  
public static void main(String ar[])  
{  
String s="Sachin";    
System.out.println(s.length());//6    
}  
}  



public class Stringoperation6  
{  
public static void main(String ar[])  
{  
String s=new String("Sachin");    
String s2=s.intern();    
System.out.println(s2);//Sachin    
}  
}  


public class Stringoperation7  
{  
public static void main(String ar[])  
{  
int a=10;    
String s=String.valueOf(a);    
System.out.println(s+10);    
}  
}