package JavaControlStatement;

//Java Program to create and call a default constructor  
class Bike1{  
//creating a default constructor  
Bike1(){System.out.println("Bike is created");}  
//main method  
public static void main(String args[]){  
//calling a default constructor  
Bike1 b=new Bike1();  
}  
} 







//Java Program to demonstrate the use of the parameterized constructor.  
class Student4{  
  int id;  
  String name;  
  //creating a parameterized constructor  
  Student4(int i,String n){  
  id = i;  
  name = n;  
  }  
  //method to display the values  
  void display(){System.out.println(id+" "+name);}  
 
  public static void main(String args[]){  
  //creating objects and passing values  
  Student4 s1 = new Student4(111,"Karan");  
  Student4 s2 = new Student4(222,"Aryan");  
  //calling method to display the values of object  
  s1.display();  
  s2.display();  
 }  
}  








//Java program to overload constructors  
class Student5{  
  int id;  
  String name;  
  int age;  
  //creating two arg constructor  
  Student5(int i,String n){  
  id = i;  
  name = n;  
  }  
  //creating three arg constructor  
  Student5(int i,String n,int a){  
  id = i;  
  name = n;  
  age=a;  
  }  
  void display(){System.out.println(id+" "+name+" "+age);}  
 
  public static void main(String args[]){  
  Student5 s1 = new Student5(111,"Karan");  
  Student5 s2 = new Student5(222,"Aryan",25);  
  s1.display();  
  s2.display();  
 }  
}  








//copy value without constructor

class Student7{  
    int id;  
    String name;  
    Student7(int i,String n){  
    id = i;  
    name = n;  
    }  
    Student7(){}  
    void display(){System.out.println(id+" "+name);}  
   
    public static void main(String args[]){  
    Student7 s1 = new Student7(111,"Karan");  
    Student7 s2 = new Student7();  
    s2.id=s1.id;  
    s2.name=s1.name;  
    s1.display();  
    s2.display();  
   }  
}  





// this keyword

class Student{  
int rollno;  
String name;  
float fee;  
Student(int r,String n,float f){  
rollno=r;  
name=n;  
fee=f;  
}  
void display(){System.out.println(rollno+" "+name+" "+fee);}  
}  
  
class TestThis3{  
public static void main(String args[]){  
Student s1=new Student(111,"ankit",5000f);  
Student s2=new Student(112,"sumit",6000f);  
s1.display();  
s2.display();  
}} 