package JavaControlStatement;

//Java Program to demonstrate the example of for loop  
//which prints table of 1  
public class ForExample {  
public static void main(String[] args) {  
  //Code of Java for loop  
  for(int i=1;i<=10;i++){  
      System.out.println(i);  
  }  
}  
}  



// while example

WhileExample.java

public class WhileExample {  
public static void main(String[] args) {  
    int i=1;  
    while(i<=10){  
        System.out.println(i);  
    i++;  
    }  
}  
}  




// do while

public class DoWhileExample {    
public static void main(String[] args) {    
    int i=1;    
    do{    
        System.out.println(i);    
    i++;    
    }while(i<=10);    
}    
}   



// break

//Java Program to demonstrate the use of break statement    
//inside the for loop.  
public class BreakExample {  
public static void main(String[] args) {  
  //using for loop  
  for(int i=1;i<=10;i++){  
      if(i==5){  
          //breaking the loop  
          break;  
      }  
      System.out.println(i);  
  }  
}  
}  


// break

//Java Program to illustrate the use of break statement    
//inside an inner loop   
public class BreakExample2 {  
public static void main(String[] args) {  
          //outer loop   
          for(int i=1;i<=3;i++){    
                  //inner loop  
                  for(int j=1;j<=3;j++){    
                      if(i==2&&j==2){    
                          //using break statement inside the inner loop  
                          break;    
                      }    
                      System.out.println(i+" "+j);    
                  }    
          }    
}  
}


// continue


//Java Program to demonstrate the use of continue statement  
//inside the while loop.  
public class ContinueWhileExample {  
public static void main(String[] args) {  
  //while loop  
  int i=1;  
  while(i<=10){  
      if(i==5){  
          //using continue statement  
          i++;  
          continue;//it will skip the rest statement  
      }  
      System.out.println(i);  
      i++;  
  }  
}  
}  