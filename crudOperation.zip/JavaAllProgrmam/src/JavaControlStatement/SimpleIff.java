package JavaControlStatement;

// if 
public class IfExample {  
public static void main(String[] args) {  
    //defining an 'age' variable  
    int age=20;  
    //checking the age  
    if(age>18){  
        System.out.print("Age is greater than 18");  
    }  
}  
}  

// if else


//A Java Program to demonstrate the use of if-else statement.  
//It is a program of odd and even number.  
public class IfElseExample {  
public static void main(String[] args) {  
  //defining a variable  
  int number=13;  
  //Check if the number is divisible by 2 or not  
  if(number%2==0){  
      System.out.println("even number");  
  }else{  
      System.out.println("odd number");  
  }  
}  
}  



// java if else if


//Java Program to demonstrate the use of If else-if ladder.  
//It is a program of grading system for fail, D grade, C grade, B grade, A grade and A+.  
public class IfElseIfExample {  
public static void main(String[] args) {  
  int marks=65;  
    
  if(marks<50){  
      System.out.println("fail");  
  }  
  else if(marks>=50 && marks<60){  
      System.out.println("D grade");  
  }  
  else if(marks>=60 && marks<70){  
      System.out.println("C grade");  
  }  
  else if(marks>=70 && marks<80){  
      System.out.println("B grade");  
  }  
  else if(marks>=80 && marks<90){  
      System.out.println("A grade");  
  }else if(marks>=90 && marks<100){  
      System.out.println("A+ grade");  
  }else{  
      System.out.println("Invalid!");  
  }  
}  
}  


// java nested if else


//Java Program to demonstrate the use of Nested If Statement.  
public class JavaNestedIfExample {    
public static void main(String[] args) {    
  //Creating two variables for age and weight  
  int age=20;  
  int weight=80;    
  //applying condition on age and weight  
  if(age>=18){    
      if(weight>50){  
          System.out.println("You are eligible to donate blood");  
      }    
  }    
}}  



//



//Java Program to demonstrate the use of Nested If Statement.    
public class JavaNestedIfExample2 {      
public static void main(String[] args) {      
  //Creating two variables for age and weight    
  int age=25;    
  int weight=48;      
  //applying condition on age and weight    
  if(age>=18){      
      if(weight>50){    
          System.out.println("You are eligible to donate blood");    
      } else{  
          System.out.println("You are not eligible to donate blood");    
      }  
  } else{  
    System.out.println("Age must be greater than 18");  
  }  
}  } 





// switch statmenet

public class SwitchExample {  
public static void main(String[] args) {  
    //Declaring a variable for switch expression  
    int number=20;  
    //Switch expression  
    switch(number){  
    //Case statements  
    case 10: System.out.println("10");  
    break;  
    case 20: System.out.println("20");  
    break;  
    case 30: System.out.println("30");  
    break;  
    //Default case statement  
    default:System.out.println("Not in 10, 20 or 30");  
    }  
}  
}  





//swicth statemetn


//Java Program to demonstrate the example of Switch statement  
//where we are printing month name for the given number  
public class SwitchMonthExample {    
public static void main(String[] args) {    
  //Specifying month number  
  int month=7;    
  String monthString="";  
  //Switch statement  
  switch(month){    
  //case statements within the switch block  
  case 1: monthString="1 - January";  
  break;    
  case 2: monthString="2 - February";  
  break;    
  case 3: monthString="3 - March";  
  break;    
  case 4: monthString="4 - April";  
  break;    
  case 5: monthString="5 - May";  
  break;    
  case 6: monthString="6 - June";  
  break;    
  case 7: monthString="7 - July";  
  break;    
  case 8: monthString="8 - August";  
  break;    
  case 9: monthString="9 - September";  
  break;    
  case 10: monthString="10 - October";  
  break;    
  case 11: monthString="11 - November";  
  break;    
  case 12: monthString="12 - December";  
  break;    
  default:System.out.println("Invalid Month!");    
  }    
  //Printing month of the given number  
  System.out.println(monthString);  
}    
}   