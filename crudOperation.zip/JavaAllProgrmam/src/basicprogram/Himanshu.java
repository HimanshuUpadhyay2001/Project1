package basicprogram;

public class Himanshu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("papa ji");
		System.out.println("Himanshu");
	}
}
