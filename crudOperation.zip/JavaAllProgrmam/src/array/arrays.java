package array;

//Java Program to illustrate how to declare, instantiate, initialize  
//and traverse the Java array.  
class Testarray{  
public static void main(String args[]){  
int a[]=new int[5];//declaration and instantiation  
a[0]=10;//initialization  
a[1]=20;  
a[2]=70;  
a[3]=40;  
a[4]=50;  
//traversing array  
for(int i=0;i<a.length;i++)//length is the property of array  
System.out.println(a[i]);  
}}  




//Java Program to illustrate the use of declaration, instantiation   
//and initialization of Java array in a single line  
class Testarray1{  
public static void main(String args[]){  
int a[]={33,3,4,5};//declaration, instantiation and initialization  
//printing array  
for(int i=0;i<a.length;i++)//length is the property of array  
System.out.println(a[i]);  
}}





//Java Program to demonstrate the way of passing an array  
//to method.  
class Testarray2{  
//creating a method which receives an array as a parameter  
static void min(int arr[]){  
int min=arr[0];  
for(int i=1;i<arr.length;i++)  
if(min>arr[i])  
min=arr[i];  

System.out.println(min);  
}  

public static void main(String args[]){  
int a[]={33,3,4,5};//declaring and initializing an array  
min(a);//passing array to method  
}}  





//Java Program to demonstrate the way of passing an anonymous array  
//to method.  
public class TestAnonymousArray{  
//creating a method which receives an array as a parameter  
static void printArray(int arr[]){  
for(int i=0;i<arr.length;i++)  
System.out.println(arr[i]);  
}  

public static void main(String args[]){  
printArray(new int[]{10,22,44,66});//passing anonymous array to method  
}}  




//Java Program to illustrate the use of multidimensional array  
class Testarray3{  
public static void main(String args[]){  
//declaring and initializing 2D array  
int arr[][]={{1,2,3},{2,4,5},{4,4,5}};  
//printing 2D array  
for(int i=0;i<3;i++){  
for(int j=0;j<3;j++){  
 System.out.print(arr[i][j]+" ");  
}  
System.out.println();  
}  
}}