package Demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/register-servlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
		HttpSession session=(HttpSession) request.getSession();

		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		// read form user input
		String username1=request.getParameter("Username");
		String password1=request.getParameter("Password");
		String email=request.getParameter("Email");
		String mob=request.getParameter("Mobile");
		Long num=Long.parseLong(mob);
		
		
		System.out.println("username="+username1);
		System.out.println("password="+password1);
		System.out.println("email="+email);
		System.out.println("mobile="+num);
		
		
		 
		 
		

		// connection create
		// load driver
		Connection con=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("driver loaded");
		}catch(Exception e) {
			e.printStackTrace();
		}
		//create connection
		String url="jdbc:mysql://localhost:3306/newproject";
		String username="root";
		String userpassword="2001";
		try {
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/newproject","root","2001");
			System.out.println("connection established");
			//query
			String q="insert into project(username1,password,email,mobile) values(?,?,?,?)";
			// create statement 
			PreparedStatement pstmt=con.prepareStatement(q);
			
			pstmt.setString(1, username1);
			pstmt.setString(2, password1);
			pstmt.setString(3, email);
			pstmt.setLong(4, num);
			
			
			pstmt.executeUpdate();
			out.println("<h1>done......</h1>");	
			
			response.sendRedirect("Login.jsp");
			
			
		}catch (Exception e) {
			e.printStackTrace();
			
			session.setAttribute("ERROR","User already Exists");
			response.sendRedirect("Register.jsp");
		}
	}

}
